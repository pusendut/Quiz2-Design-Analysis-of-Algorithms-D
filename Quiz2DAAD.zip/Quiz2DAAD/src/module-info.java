/**
 * 
 */
/**
 * 
 */
module Quiz2DAAD {
    exports mazegame;
}