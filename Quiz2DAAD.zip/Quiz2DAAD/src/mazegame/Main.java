package mazegame;

public class Main {
    public static void main(String[] args) {
        int[][] mazeLayout = {
            {0, 1, 0, 0, 0},
            {0, 1, 0, 1, 0},
            {0, 0, 0, 1, 0},
            {0, 1, 0, 0, 0},
            {0, 0, 0, 1, 0}
        };

        Maze maze = new Maze(mazeLayout, 0, 0, 4, 4);
        Game game = new Game(maze);
        game.start();
    }
}
