package mazegame;

public class Player {
    private int row;
    private int col;

    // Constructor
    public Player(int startRow, int startCol) {
        this.row = startRow;
        this.col = startCol;
    }

    // Getters and setters
    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    // Method to move the player
    public void move(int newRow, int newCol) {
        this.row = newRow;
        this.col = newCol;
    }
}
