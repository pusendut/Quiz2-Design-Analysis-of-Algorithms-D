package mazegame;

public class Maze {
    private final int[][] maze;
    private final int rows;
    private final int cols;
    private final int startRow;
    private final int startCol;
    private final int exitRow;
    private final int exitCol;

    // Constructor
    public Maze(int[][] maze, int startRow, int startCol, int exitRow, int exitCol) {
        this.maze = maze;
        this.rows = maze.length;
        this.cols = maze[0].length;
        this.startRow = startRow;
        this.startCol = startCol;
        this.exitRow = exitRow;
        this.exitCol = exitCol;
    }

    // Getters
    public int getRows() {
        return rows;
    }

    public int getCols() {
        return cols;
    }

    public int getStartRow() {
        return startRow;
    }

    public int getStartCol() {
        return startCol;
    }

    public int getExitRow() {
        return exitRow;
    }

    public int getExitCol() {
        return exitCol;
    }

    // Method to check if a cell is a valid move
    public boolean isValidMove(int row, int col) {
        return row >= 0 && row < rows && col >= 0 && col < cols && maze[row][col] == 0;
    }
}
