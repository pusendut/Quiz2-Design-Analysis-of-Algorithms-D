package mazegame;

import java.util.Scanner;

public class Game {
    private Maze maze;
    private Player player;

    // Enum to represent player movement directions
    private enum Direction {
        UP, DOWN, LEFT, RIGHT
    }

    public Game(Maze maze) {
        this.maze = maze;
        this.player = new Player(maze.getStartRow(), maze.getStartCol());
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);
        printMaze();

        while (true) {
            System.out.print("Enter your move (W/A/S/D): ");
            String move = scanner.nextLine().toUpperCase();

            if (move.equals("W")) {
                movePlayer(Direction.UP);
            } else if (move.equals("S")) {
                movePlayer(Direction.DOWN);
            } else if (move.equals("A")) {
                movePlayer(Direction.LEFT);
            } else if (move.equals("D")) {
                movePlayer(Direction.RIGHT);
            } else {
                System.out.println("Invalid move! Use W/A/S/D.");
            }

            if (player.getRow() == maze.getExitRow() && player.getCol() == maze.getExitCol()) {
                System.out.println("Congratulations! You reached the exit!");
                break;
            }
        }

        scanner.close();
    }

    private void movePlayer(Direction direction) {
        int newRow = player.getRow();
        int newCol = player.getCol();

        switch (direction) {
            case UP:
                newRow--;
                break;
            case DOWN:
                newRow++;
                break;
            case LEFT:
                newCol--;
                break;
            case RIGHT:
                newCol++;
                break;
        }

        if (maze.isValidMove(newRow, newCol)) {
            player.move(newRow, newCol);
            printMaze();
        } else {
            System.out.println("Invalid move! Try again.");
        }
    }

    private void printMaze() {
        for (int i = 0; i < maze.getRows(); i++) {
            for (int j = 0; j < maze.getCols(); j++) {
                if (i == player.getRow() && j == player.getCol()) {
                    System.out.print("P ");
                } else if (i == maze.getExitRow() && j == maze.getExitCol()) {
                    System.out.print("E ");
                } else if (maze.isValidMove(i, j)) {
                    System.out.print(". ");
                } else {
                    System.out.print("# ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }
}
